import { McpServer } from "@modelcontextprotocol/server/mcp.js";
import { WebStandardStreamableHTTPServerTransport } from "@modelcontextprotocol/server/webStandardStreamableHttp.js";
import { registerAppResource, registerAppTool, RESOURCE_MIME_TYPE } from "@modelcontextprotocol/ext-apps/server";
import { z } from "zod";
import fs from "node:fs/promises";
import path from "node:path";

const RESOURCE_URI = "ui://rifi-kreasi/studio.html";

async function buildServer() {
  const server = new McpServer({
    name: "rifi-kreasi-ai-studio",
    version: "1.1.1",
  });

  registerAppTool(
    server,
    "rifi_kreasi_studio",
    {
      title: "RiFi Kreasi Studio",
      description:
        "Open the RiFi Kreasi interactive creative production studio. The workflow is fixed at four STEP and includes clickable choices, custom input, production fields, review and generation.",
      inputSchema: z.object({
        start: z.boolean().optional().default(true),
      }),
      _meta: {
        ui: {
          resourceUri: RESOURCE_URI,
        },
      },
    },
    async ({ start }) => ({
      content: [
        {
          type: "text",
          text: start
            ? "RiFi Kreasi Studio siap digunakan. Buka panel interaktif untuk memulai STEP 1."
            : "RiFi Kreasi Studio tersedia.",
        },
      ],
      structuredContent: {
        app: "rifi-kreasi",
        version: "1.1.1",
        steps: 4,
      },
    }),
  );

  registerAppResource(
    server,
    "RiFi Kreasi Studio",
    RESOURCE_URI,
    {
      description: "RiFi Kreasi four-step interactive production workspace.",
      mimeType: RESOURCE_MIME_TYPE,
    },
    async () => {
      const html = await fs.readFile(
        path.join(process.cwd(), "mcp-app.html"),
        "utf8",
      );

      return {
        contents: [
          {
            uri: RESOURCE_URI,
            mimeType: RESOURCE_MIME_TYPE,
            text: html,
          },
        ],
      };
    },
  );

  return server;
}

export default async function handler(request) {
  // Netlify's Function receives a Web-standard Request.
  // MCP's WebStandard transport is designed for exactly this runtime.
  if (request.method !== "POST") {
    return new Response("Method Not Allowed", {
      status: 405,
      headers: { Allow: "POST" },
    });
  }

  const server = await buildServer();

  const transport = new WebStandardStreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: true,
  });

  await server.connect(transport);
  return transport.handleRequest(request);
}

export const config = {
  path: "/mcp",
  rateLimit: {
    windowSize: 60,
    windowLimit: 60,
    aggregateBy: ["ip"],
  },
};
