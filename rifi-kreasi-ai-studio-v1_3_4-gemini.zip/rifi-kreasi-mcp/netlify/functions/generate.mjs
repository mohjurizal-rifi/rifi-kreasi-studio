const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
export default async (req) => {
  if (req.method === 'OPTIONS') return new Response('', { status: 204, headers });
  if (req.method !== 'POST') return Response.json({ error: 'Gunakan metode POST.' }, { status: 405, headers });
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return Response.json({ error: 'GEMINI_API_KEY belum dipasang di Netlify → Site configuration → Environment variables.' }, { status: 503, headers });
  try {
    const input = await req.json();
    const count = Math.min(30, Math.max(1, Number(input.sceneCount) || 5));
    const prompt = `Kamu adalah RiFi Kreasi AI Studio, creative director dan production director profesional. Buat paket produksi konten FINAL dalam bahasa ${input.brief?.language || 'Indonesia'}. Jangan mengubah studio, kategori, arah, ide, atau style yang dipilih. Jangan tulis placeholder, instruksi untuk pengguna, atau tanda kurung siku berisi perintah. Semua prompt dan VO harus benar-benar ditulis.
PROJECT: ${JSON.stringify(input)}
Hasilkan tepat ${count} scene. Alur wajib: hook/pembuka, pengembangan, puncak/inti, penutup (sesuaikan bila scene lebih sedikit). Setiap scene wajib memiliki visual_action yang spesifik dan berbeda, image_prompt lengkap, video_prompt lengkap (aksi subjek, gerak kamera, ekspresi, kontinuitas, transisi, audio), voice_over aktual dan duration. VO per scene harus membentuk naskah utuh dan sesuai format narasi yang dipilih. Jika tanpa narasi, voice_over berupa string kosong. Prompt gambar menjaga konsistensi karakter, lokasi, properti, rasio dan visual style. Untuk fakta/edukasi, jangan mengarang angka atau klaim; beri catatan verifikasi bila perlu. Untuk affiliate/iklan, jangan mengarang spesifikasi produk yang tidak diberikan.
Kembalikan HANYA JSON valid dengan skema: {"title":"...","caption":"...","hashtags":["..."],"cta":"...","fact_check_notes":"...","scenes":[{"duration":"...","visual_action":"...","image_prompt":"...","video_prompt":"...","voice_over":"..."}]}. Pastikan scenes berjumlah tepat ${count}.`;
    const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.7 } }) });
    const body = await response.json();
    if (!response.ok) return Response.json({ error: body.error?.message || `Gemini API error ${response.status}` }, { status: response.status, headers });
    const raw = body.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
    const result = JSON.parse(raw.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim());
    if (!Array.isArray(result.scenes) || result.scenes.length !== count) throw new Error(`Gemini mengembalikan ${result.scenes?.length || 0} scene, seharusnya ${count}.`);
    return Response.json({ result, model }, { status: 200, headers });
  } catch (error) {
    return Response.json({ error: error.message || 'Terjadi kesalahan saat memproses permintaan.' }, { status: 500, headers });
  }
};
