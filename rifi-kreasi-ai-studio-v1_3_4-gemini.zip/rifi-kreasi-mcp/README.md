# RiFi Kreasi AI Studio v1.3.4

Pembaruan dari source asli v1.3.3. Empat studio, bank ide, desain, dan alur empat STEP dipertahankan. STEP 4 kini memanggil Gemini melalui Netlify Function untuk menghasilkan storyboard, prompt gambar, prompt video, VO per scene, VO lengkap, judul, caption, hashtag, dan CTA.

## Persiapan Gemini (sekali saja)

1. Buat atau gunakan API key Gemini dari Google AI Studio: https://aistudio.google.com/apikey
2. Deploy folder proyek ini ke Netlify.
3. Di Netlify buka **Site configuration → Environment variables**.
4. Tambahkan `GEMINI_API_KEY` dengan nilai API key kamu. Jangan tempel API key ke `app.js` atau membagikannya.
5. (Opsional) Tambahkan `GEMINI_MODEL` dengan nilai `gemini-2.5-flash`. Jika model tidak tersedia untuk akun/region/kuota, pilih model Flash yang tersedia di Google AI Studio.
6. Redeploy site setelah menambahkan environment variable.
7. Buka web app, pilih salah satu dari empat studio, isi STEP 1–3, lalu tekan **GENERATE DENGAN GEMINI** pada STEP 4.

## Catatan biaya dan batasan

- Aplikasi tidak memerlukan server yang dikelola sendiri; fungsi berjalan melalui Netlify Functions. Paket gratis Netlify dan kuota gratis Gemini dapat berubah serta memiliki batas pemakaian. Penggunaan API di luar kuota gratis dapat dikenakan biaya oleh Google. Periksa dashboard Google AI Studio/Cloud sebelum penggunaan rutin.
- Gemini menghasilkan teks produksi dan prompt. File ini belum merender gambar atau video secara langsung. Untuk menghasilkan media, salin prompt ke layanan gambar/video yang kamu pilih.
- Upload foto pada UI v1.3.4 masih untuk preview lokal; pengiriman gambar sebagai input multimodal Gemini belum diaktifkan pada versi ini. Jangan menganggap foto sudah dianalisis oleh Gemini.
- Bila API key belum disetel, STEP 4 akan menampilkan petunjuk konfigurasi, bukan hasil palsu.

## Yang dipertahankan

- Empat studio: Animation AI, Affiliate AI, Drama AI, AI Influencer & Ads.
- STEP 1 dengan tiga lapisan pilihan, 20 ide per jalur, dan kolom CUSTOM.
- STEP 2 dengan 16 visual style dan CUSTOM.
- STEP 3 dengan sembilan bidang brief, input custom, dan preview foto.
- Layout responsif, data ide, logo, aset, serta endpoint MCP lama.

## Struktur penting

- `index.html`, `styles.css`, `app.js`: antarmuka dan alur pengguna.
- `animation-data.js`, `brain-data.js`: bank ide dan instruksi studio.
- `netlify/functions/generate.mjs`: backend aman untuk Gemini.
- `netlify/functions/mcp.mjs`: integrasi MCP lama, dipertahankan.
- `netlify.toml`: konfigurasi deploy Netlify.

## Pengujian

Jalankan `node --check app.js` dan `node --check netlify/functions/generate.mjs`. Pengujian live Gemini memerlukan API key dan deployment Netlify.
