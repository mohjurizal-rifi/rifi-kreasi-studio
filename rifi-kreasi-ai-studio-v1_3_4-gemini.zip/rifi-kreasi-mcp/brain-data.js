/* RiFi Kreasi · OTAK Drama / Affiliate / Influencer
   Format: BRAIN_SUBS[modul][nama kategori layar 1] = [[emoji, nama layar 2, '5 subjek spesifik dipisah ;'], ...10 item]
   Layar 2 = 10 arah yang hanya mengikuti kategori layar 1. Layar 3 = 20 ide yang hanya mengikuti layar 1 + 2. */
const BRAIN_SUBS={
drama:{
'Romance':[
['🌱','Cinta Pertama','Surat tanpa nama di loker;Payung yang dipinjamkan;Teman sebangku yang diam-diam suka;Pertemuan di perpustakaan;Lagu yang dimainkan di halte'],
['🔄','Cinta Lama Bersemi Kembali','Reuni sekolah;Mantan yang jadi atasan baru;Kota kecil penuh kenangan;Foto lama di dalam buku;Pesan setelah sepuluh tahun'],
['💍','Perjodohan','Calon yang tidak diinginkan;Kesepakatan selama setahun;Dua keluarga bersahabat;Pertemuan pertama yang canggung;Perasaan yang datang terlambat'],
['📞','Cinta Jarak Jauh','Video call tengah malam;Beda zona waktu;Paket kejutan dari seberang;Janji bertemu di stasiun;Pesan terakhir sebelum berangkat'],
['🌈','Cinta Beda Latar','Anak kos dan anak pemilik kafe;Seniman dan akuntan;Orang kota dan warga desa;Dua budaya dalam satu meja;Mencari restu keluarga'],
['🤝','Friends to Lovers','Sahabat sejak kecil;Rekan satu tim;Tetangga sebelah rumah;Teman curhat setia;Perjalanan berdua'],
['🔺','Cinta Segitiga','Dua pilihan satu hati;Sahabat menyukai orang yang sama;Teman lama datang kembali;Pesan salah kirim;Pilihan di hari penting'],
['💼','Romansa di Tempat Kerja','Rekan baru di kantor;Rapat yang terlalu lama;Lembur berdua;Proyek bersama;Kopi pagi di pantry'],
['🍂','Romansa Musiman','Hujan di musim pancaroba;Festival lampion;Liburan akhir tahun;Musim panen di desa;Mudik dan pertemuan'],
['🕊️','Pengorbanan dan Janji','Janji di bawah pohon;Mengalah demi mimpi;Menunggu tanpa kepastian;Surat untuk masa depan;Hadiah sederhana penuh makna']],
'Thriller & Misteri':[
['✉️','Pesan Misterius','Nomor tak dikenal;Surat tanpa pengirim;Kode di buku catatan;Pesan suara aneh;Paket tanpa alamat'],
['🔦','Hilangnya Seseorang','Teman yang tak pulang;Kursi kosong di kelas;Jejak terakhir di CCTV;Barang yang tertinggal;Pencarian di malam hari'],
['🗝️','Rahasia Keluarga','Foto yang disembunyikan;Ruangan terkunci;Nama yang tak pernah disebut;Surat wasiat;Cerita kakek yang berubah'],
['🎭','Identitas Tersembunyi','Tetangga baru;Dua orang berwajah mirip;Nama palsu;Rekan kerja misterius;Foto lama dengan wajah berbeda'],
['🕵️','Detektif Amatir','Murid memecahkan teka-teki;Penjaga toko yang jeli;Kurir yang melihat sesuatu;Penulis yang menyelidiki;Warga yang curiga'],
['🏘️','Lingkungan yang Janggal','Lampu menyala tiap malam;Suara dari rumah kosong;Pagar yang berpindah;Tetangga yang tak pernah keluar;Lorong apartemen yang sunyi'],
['🧩','Permainan Pikiran','Teka-teki dari orang asing;Tantangan tengah malam;Permainan yang berbalik;Saksi yang berbohong;Waktu yang terus berulang'],
['🚌','Perjalanan Mencurigakan','Bus malam penuh rahasia;Kereta tanpa tujuan;Penginapan terpencil;Mobil yang mengikuti;Peta tanpa nama'],
['📱','Misteri Dunia Digital','Akun anonim;Pesan yang terhapus;Foto tanpa asal;Rekaman layar janggal;Notifikasi dari akun lama'],
['🔀','Twist Akhir','Saksi ternyata pelaku;Korban menyimpan kunci;Waktu yang salah;Mimpi yang jadi petunjuk;Surat dari diri sendiri']],
'Horor':[
['🏚️','Rumah Berhantu','Kamar yang selalu dingin;Cermin retak;Bayangan di jendela;Boneka di loteng;Lampu yang berkedip'],
['🏫','Sekolah Angker','Toilet di ujung koridor;Bel tengah malam;Kelas kosong;Lonceng tua;Buku absen misterius'],
['🌳','Legenda Desa','Pantangan di hutan;Sumur tua;Pohon besar;Jembatan angker;Suara dari tengah sawah'],
['👤','Penunggu Tempat','Lift tengah malam;Kamar hotel bernomor tertentu;Pos ronda;Gedung tua;Kos-kosan lama'],
['🪞','Benda Terkutuk','Cermin antik;Radio tua;Kotak musik;Lukisan misterius;Kalung peninggalan'],
['🌙','Mimpi dan Gangguan Tidur','Mimpi yang berulang;Paralisis tidur;Suara dari bawah ranjang;Langkah di lorong;Bisikan di telinga'],
['🛣️','Perjalanan Malam','Jalan sepi;Tumpangan misterius;Hutan saat berkemah;Bus terakhir;Pom bensin yang sunyi'],
['📱','Horor Dunia Digital','Video yang tak bisa dihapus;Pesan dari nomor lama;Panggilan tanpa suara;Foto dengan bayangan;Game yang menyala sendiri'],
['🕯️','Uji Nyali Persahabatan','Tantangan malam Jumat;Permainan jelangkung dalam cerita;Menginap di rumah tua;Foto bersama yang janggal;Rahasia yang dibawa pulang'],
['🧸','Horor Ringan Keluarga','Anak kecil bicara sendiri;Mainan yang berpindah;Nenek yang melarang;Pintu terbuka sendiri;Kejadian aneh jam tiga']],
'Komedi':[
['🙈','Kesalahpahaman Lucu','Pesan salah kirim;Orang salah panggil;Undangan salah alamat;Paket tertukar;Nama yang mirip'],
['🎓','Kehidupan Kos dan Kampus','Anak kos kehabisan uang;Tugas mendadak dari dosen;Teman sekamar unik;Ujian dadakan;Organisasi kampus yang heboh'],
['👨‍👩‍👧','Keluarga Konyol','Ayah dan teknologi;Ibu dan grup WhatsApp;Kakak adik berebut remote;Nenek dan ponsel baru;Arisan keluarga'],
['🏢','Kantor Penuh Tawa','Rapat yang salah topik;Atasan dan meme;Kopi habis;Lembur penuh drama;Presentasi gagal'],
['🏘️','Warga dan Tetangga','Rapat RT;Arisan ibu-ibu;Lomba 17 Agustus;Ronda malam;Tetangga baru yang unik'],
['💘','Percintaan Kocak','Kencan pertama gagal;Gombalan yang salah;Cemburu salah paham;Mantan datang tiba-tiba;Menyatakan cinta lewat teman'],
['🐱','Hewan Peliharaan Kocak','Kucing pencuri makanan;Anjing yang takut kucing;Burung beo pembocor rahasia;Ikan yang dinamai mantan;Kelinci yang kabur'],
['🎒','Sekolah dan Anak-anak','Anak polos berkomentar jujur;Guru dan murid usil;Hari pertama sekolah;Lomba cerdas cermat;Contekan yang gagal'],
['🤦','Hari Sial yang Lucu','Alarm tidak berbunyi;Dompet tertinggal;Salah naik angkot;Ban bocor di saat penting;Hujan di hari jemuran'],
['📲','Teknologi dan Media Sosial','Live streaming salah klik;Filter yang tak bisa dimatikan;Voice note terkirim ke atasan;Video call lupa mute;Salah memakai aplikasi']],
'Melodrama Keluarga':[
['🤲','Pengorbanan Orang Tua','Ibu bekerja malam hari;Ayah menyimpan mimpinya;Orang tua menjual barang berharga;Hadiah dari tabungan lama;Surat dari ayah'],
['👫','Kakak dan Adik','Kakak yang selalu mengalah;Adik yang salah paham;Warisan kecil;Rahasia di masa kecil;Saling melindungi'],
['🕊️','Rekonsiliasi','Maaf yang tertunda;Reuni keluarga;Surat lama ditemukan;Ayah dan anak yang lama diam;Meja makan yang kembali ramai'],
['🧳','Anak Perantau','Pulang kampung;Telepon dari ibu;Kerja jauh tanpa kabar;Kamar masa kecil;Oleh-oleh dari kota'],
['🏠','Warisan dan Rumah','Rumah penuh kenangan;Barang peninggalan;Kebun keluarga;Perselisihan pembagian;Wasiat yang sederhana'],
['📚','Anak yang Berjuang','Sekolah dengan keterbatasan;Beasiswa;Menjadi tulang punggung keluarga;Mimpi di tengah kesulitan;Guru yang percaya'],
['👵','Nenek, Kakek dan Cucu','Resep nenek;Cerita kakek;Rumah di desa;Kenangan di dapur;Pesan terakhir'],
['🔓','Rahasia yang Terbuka','Anak angkat;Foto yang disembunyikan;Surat yang tak terkirim;Hubungan masa lalu;Nama yang berubah'],
['🎊','Hari Besar dan Tradisi','Lebaran yang berbeda;Natal tanpa orang tersayang;Ulang tahun yang terlupa;Pernikahan keluarga;Mudik penuh haru'],
['🌅','Harapan Kedua','Memulai kembali;Usaha keluarga bangkit;Masa pemulihan;Persahabatan yang menolong;Mimpi yang akhirnya terwujud']],
'Action & Petualangan':[
['🆘','Misi Penyelamatan','Menyelamatkan teman di hutan;Evakuasi saat banjir;Mencari anak yang hilang;Misi di gunung;Menolong di laut'],
['🗺️','Perburuan Harta','Peta tua;Kunci tersembunyi;Gua misterius;Kapal karam;Petunjuk di candi'],
['🏃','Pelarian dan Pengejaran','Kejar-kejaran di pasar;Pelarian di kereta;Menyelinap di malam hari;Menghindari kejaran;Jembatan yang rapuh'],
['🏔️','Petualang Alam','Menyeberangi sungai;Menembus hutan;Mendaki tebing;Menjelajah gua;Menghadapi badai'],
['🕶️','Tim dan Misi Rahasia','Tim kecil berbakat;Agen tak dikenal;Dokumen penting;Penyamaran;Waktu yang menipis'],
['🧙','Fantasi dan Dunia Lain','Pintu ke dunia lain;Pedang legendaris;Hutan ajaib;Kerajaan tersembunyi;Makhluk penjaga'],
['🥋','Pertarungan dan Ketahanan','Turnamen bela diri;Latihan keras;Lawan tak terduga;Balas budi;Pertarungan terakhir'],
['🤖','Dunia Masa Depan','Kota robot;Misi di luar angkasa;Pelarian dari laboratorium;Kecerdasan buatan memberontak;Portal waktu'],
['🏎️','Kendaraan dan Kecepatan','Balap di jalan sepi;Kapal di tengah badai;Kereta yang melaju;Pesawat darurat;Sepeda gunung'],
['🛡️','Persahabatan dalam Bahaya','Teman yang berkhianat;Tim yang saling menjaga;Pilihan sulit;Pengorbanan di akhir;Kemenangan bersama']]
},
affiliate:{
'Beauty & Skincare':[
['🧴','Perawatan Wajah','Pembersih wajah;Tabir surya;Serum;Pelembap;Masker wajah'],
['💇','Perawatan Rambut','Sampo;Kondisioner;Serum rambut;Sisir dan pengering;Masker rambut'],
['💄','Makeup Harian','Lip tint;Bedak;Maskara;Alas bedak;Pensil alis'],
['🛁','Perawatan Tubuh','Sabun mandi;Body lotion;Scrub tubuh;Deodoran;Minyak pijat'],
['🪞','Alat Kecantikan','Sisir listrik;Roller wajah;Cermin LED;Pouch kosmetik;Pengikat rambut'],
['🦷','Perawatan Bibir dan Gigi','Lip balm;Pasta gigi;Sikat gigi listrik;Pembersih lidah;Obat kumur'],
['🎁','Paket Hadiah Kecantikan','Gift set;Travel kit;Paket pemula;Sheet mask;Parfum mini'],
['🌗','Rutinitas Pagi dan Malam','Rutinitas tiga langkah;Perawatan malam;Persiapan pagi;Wadah travel;Organizer meja rias'],
['🧔','Perawatan Pria','Pembersih wajah pria;Pomade;Alat cukur;Parfum pria;Pelembap pria'],
['🌸','Perawatan Kulit Sensitif','Pelembap lembut;Sabun tanpa pewangi;Pelindung kulit;Pembersih mikelar;Krim penenang']],
'Fashion & Aksesori':[
['👜','Tas','Tas selempang;Ransel harian;Tote bag;Tas kerja;Dompet'],
['👟','Sepatu dan Alas Kaki','Sneakers;Sandal nyaman;Sepatu kerja;Sepatu lari;Kaus kaki'],
['👕','Pakaian Harian','Kaos basic;Kemeja;Celana;Dress;Outer'],
['🧕','Hijab dan Busana Muslimah','Pashmina;Hijab instan;Outer panjang;Inner hijab;Gamis'],
['⌚','Aksesori','Jam tangan;Kalung;Gelang;Kacamata;Topi'],
['🕴️','Fashion Pria','Kemeja pria;Jaket;Ikat pinggang;Celana chino;Topi pria'],
['🎉','Outfit Acara','Pakaian pesta;Batik;Kebaya;Setelan formal;Aksesori pesta'],
['🧒','Fashion Anak','Baju anak;Sepatu anak;Tas sekolah;Topi anak;Aksesori rambut'],
['🧺','Perawatan Pakaian','Setrika uap;Rak baju;Pembersih noda;Gantungan;Lint roller'],
['🎀','Hadiah Fashion','Scarf;Dompet kecil;Set aksesori;Tas mini;Jam tangan pasangan']],
'Home & Kitchen':[
['🍳','Alat Masak','Wajan anti lengket;Panci;Rice cooker;Air fryer;Blender'],
['🥫','Penyimpanan Dapur','Toples;Rak piring;Wadah makan;Botol bumbu;Kotak bekal'],
['🍽️','Peralatan Makan','Piring;Gelas;Sendok dan garpu;Tumbler;Mangkuk'],
['🧹','Kebersihan Rumah','Sapu;Pel;Pembersih lantai;Sikat serbaguna;Lap mikrofiber'],
['🛋️','Dekorasi Rumah','Lampu meja;Vas;Bantal sofa;Tirai;Cermin dinding'],
['🗄️','Organizer Rumah','Rak sepatu;Kotak penyimpanan;Rak gantung;Organizer lemari;Hook perekat'],
['🛏️','Kamar Tidur','Sprei;Bantal;Selimut;Lampu tidur;Diffuser'],
['🚿','Kamar Mandi','Rak kamar mandi;Keset;Gantungan handuk;Dispenser sabun;Showerhead'],
['🔪','Alat Kecil Dapur','Pemotong sayur;Timbangan dapur;Pengocok telur;Parutan;Penutup makanan'],
['🪴','Taman dan Teras','Pot tanaman;Penyiram tanaman;Lampu taman;Kursi lipat;Rak tanaman']],
'Gadget & Teknologi':[
['📱','Aksesori Ponsel','Casing;Tempered glass;Holder ponsel;Kabel data;Ring stand'],
['🎧','Audio','Earphone;Headset;Speaker mini;Mikrofon;Headphone'],
['🔋','Pengisian Daya','Power bank;Charger;Kabel gulung;Stasiun pengisian;Colokan'],
['💻','Kerja dari Rumah','Keyboard;Mouse;Webcam;Laptop stand;Lampu meja kerja'],
['🏠','Smart Home','Lampu pintar;Colokan pintar;Kamera rumah;Speaker pintar;Sensor pintar'],
['📸','Fotografi dan Konten','Tripod;Ring light;Mikrofon clip-on;Gimbal;Lensa tambahan'],
['🎮','Gaming','Controller;Headset gaming;Mouse pad;Kipas ponsel;Trigger ponsel'],
['⌚','Wearable','Smartwatch;Gelang kebugaran;Earbud;Casing jam;Tali jam'],
['💾','Penyimpanan Data','Flashdisk;Hard disk eksternal;Kartu memori;Card reader;Hub USB'],
['🧳','Gadget Perjalanan','Adaptor travel;Power bank slim;Pelacak barang;Bantal leher;Tas kabel']],
'Daily-use Products':[
['🧼','Kebersihan Pribadi','Hand sanitizer;Tisu basah;Sabun cuci tangan;Masker;Pemotong kuku'],
['🥤','Botol dan Tumbler','Botol minum;Tumbler;Botol lipat;Botol olahraga;Gelas lipat'],
['📝','Alat Tulis dan Kantor','Buku catatan;Pulpen;Planner;Stabilo;Organizer meja'],
['🛵','Perawatan Kendaraan','Pembersih helm;Jas hujan;Cover motor;Holder motor;Parfum mobil'],
['🎒','Perjalanan Harian','Payung;Tas lipat;Organizer koper;Botol travel;Gantungan kunci pelacak'],
['🩹','Kesehatan Ringan','Plester;Kotak P3K;Termometer;Alat pijat;Penghangat'],
['🏸','Hobi dan Aktivitas','Alat olahraga;Matras yoga;Tali lompat;Alat pancing;Perlengkapan melukis'],
['☔','Kebutuhan Musim Hujan','Jas hujan;Sepatu anti air;Payung lipat;Tas kedap air;Cover tas'],
['🔦','Elektronik Kecil','Baterai;Lampu darurat;Senter;Kipas mini;Colokan tambahan'],
['🧰','Peralatan Praktis','Pembuka kemasan;Gunting;Selotip;Tali pengikat;Perekat serbaguna']],
'Family & Baby':[
['🍼','Perlengkapan Bayi','Botol susu;Gendongan;Selimut bayi;Tas bayi;Popok kain'],
['🧩','Mainan Edukasi','Puzzle;Balok susun;Buku anak;Mainan musik;Flashcard'],
['🎒','Perlengkapan Sekolah','Tas sekolah;Kotak makan;Botol minum anak;Alat tulis;Sepatu sekolah'],
['👶','Pakaian Anak dan Bayi','Jumper;Kaus kaki bayi;Topi;Piyama;Bodysuit'],
['🛡️','Keamanan Anak','Pengaman stopkontak;Pelindung sudut;Kursi mobil;Pagar bayi;Pelacak anak'],
['🥣','Makan Bayi dan Anak','Peralatan MPASI;Slabber;Piring suction;Sendok bayi;Blender kecil'],
['🌙','Tidur Anak','Kasur bayi;Lampu tidur;Boneka;Selimut;Diffuser'],
['🚼','Perjalanan Keluarga','Stroller;Tas bepergian;Bantal leher anak;Tikar;Organizer koper'],
['🎲','Aktivitas Keluarga','Permainan papan;Perlengkapan piknik;Alat mewarnai;Sepeda anak;Proyek DIY'],
['🎁','Hadiah untuk Anak','Set mainan;Buku cerita;Alat lukis;Pakaian anak;Perlengkapan sekolah']]
},
influencer:{
'Profil Influencer Virtual':[
['🪪','Identitas dan Persona','Nama dan kepribadian;Latar belakang cerita;Gaya bicara;Nilai dan misi;Ciri khas visual'],
['👗','Penampilan dan Wardrobe','Gaya sehari-hari;Wardrobe signature;Palet warna;Aksesori khas;Penampilan musiman'],
['🎯','Niche dan Positioning','Niche teknologi;Niche gaya hidup;Niche edukasi;Niche hiburan;Niche kuliner'],
['🧬','Konsistensi Karakter','Character sheet;Ekspresi wajah;Pose utama;Lokasi tetap;Prompt konsisten'],
['📖','Origin Story','Asal-usul karakter;Misi karakter;Momen penting;Keunikan;Pesan utama'],
['💬','Interaksi dengan Audiens','Sapaan khas;Sesi tanya jawab;Respons komentar;Ritual video;Catchphrase'],
['🏷️','Bio dan Branding','Bio profil;Tagline;Gaya logo;Highlight profil;Tema feed'],
['🗓️','Rencana Konten Mingguan','Hari perkenalan;Hari edukasi;Hari hiburan;Hari produk;Hari interaksi'],
['🤝','Kolaborasi Virtual','Duet karakter;Kolaborasi brand;Tamu undangan;Event virtual;Challenge'],
['👥','Pengembangan Komunitas','Nama komunitas;Tradisi komunitas;Giveaway etis;Polling;Misi komunitas']],
'Product Showcase':[
['📦','Unboxing Estetik','Detail kemasan;Reveal pertama;Isi paket;Close-up;Kesan pertama'],
['⚙️','Demo Fitur','Fitur utama;Cara pakai;Hasil nyata;Detail kecil;Tips penggunaan'],
['🔍','Close-up Detail','Material;Tekstur;Warna;Ukuran;Finishing'],
['🧩','Problem dan Solution','Masalah umum;Solusi yang ditawarkan;Perbandingan cara lama;Rutinitas baru;Hasil yang wajar'],
['🏠','Lifestyle Placement','Di meja kerja;Di dapur;Di tas harian;Di perjalanan;Di kamar'],
['🎨','Perbandingan Varian','Pilihan warna;Pilihan ukuran;Pilihan paket;Pilihan fungsi;Pilihan harga'],
['🔄','360° Product Reveal','Putaran produk;Zoom perlahan;Slow motion;Permainan cahaya;Latar bersih'],
['🕒','Use Case Harian','Pagi hari;Di kantor;Malam hari;Akhir pekan;Saat bepergian'],
['🎁','Bundle dan Hadiah','Paket hemat;Ide hadiah;Set lengkap;Edisi musim;Kemasan hadiah'],
['🎄','Showcase Musiman','Akhir tahun;Ramadan;Tahun ajaran baru;Musim hujan;Liburan']],
'UGC & Review Berskrip':[
['⭐','Review Jujur Berskrip','Kesan pertama;Kelebihan;Hal yang perlu dipertimbangkan;Cocok untuk siapa;Kesimpulan'],
['🗣️','Cerita Pengguna Berlabel','Cerita pengguna;Alasan memilih;Pengalaman pemakaian;Kebiasaan baru;Saran'],
['🧑‍🏫','Tutorial Singkat','Langkah awal;Tips penting;Kesalahan umum;Trik kecil;Cara merawat'],
['📅','Day in My Life','Rutinitas pagi;Hari kerja;Hari belanja;Hari santai;Akhir pekan'],
['❓','Tanya Jawab','Pertanyaan umum;Keraguan pembeli;Perbandingan;Garansi dan kebijakan;Cara membeli'],
['😲','Reaksi Pertama','Reaksi membuka paket;Reaksi mencoba;Kejutan kecil;Harapan versus kenyataan;Reaksi akhir'],
['📆','Tantangan Tujuh Hari','Hari pertama;Hari ketiga;Hari kelima;Hari ketujuh;Rangkuman'],
['⚖️','Perbandingan Jujur','Produk A versus B;Harga versus fungsi;Cocok untuk;Kurang cocok untuk;Rekomendasi'],
['📚','Storytelling Pengguna','Masalah awal;Pencarian solusi;Menemukan produk;Perubahan kecil;Cerita akhir'],
['🎣','Hook Gaya Media Sosial','Stop scroll;Fakta cepat;Rahasia kecil;Kesalahan umum;Ajakan lembut']],
'Lifestyle & Fashion':[
['👗','Outfit of the Day','OOTD kerja;OOTD santai;OOTD akhir pekan;OOTD hujan;OOTD acara'],
['🧩','Mix and Match','Basic jadi stylish;Satu item tiga gaya;Warna netral;Padu padan batik;Layering'],
['🌅','Rutinitas Pagi','Bangun tidur;Sarapan;Berdandan;Siap kerja;Berangkat'],
['🛍️','Wishlist dan Haul','Belanja bulanan;Wishlist;Haul hemat;Thrift;Pilihan terbaik'],
['🥗','Gaya Hidup Sehat','Olahraga ringan;Minum cukup;Tidur teratur;Jalan pagi;Makan seimbang'],
['🖥️','Home dan Desk Setup','Meja kerja;Kamar;Sudut baca;Dekorasi;Pencahayaan'],
['👚','Capsule Wardrobe','Sepuluh item;Pilihan warna;Per musim;Untuk kerja;Untuk perjalanan'],
['🛀','Self-care Day','Perawatan kulit;Pijat;Membaca;Musik;Istirahat'],
['💸','Fashion Hemat','Gaya hemat;Thrift;Rotasi pakaian;Item basic;Investasi bijak'],
['🔥','Tren Musiman','Tren warna;Tren aksesori;Tren sepatu;Tren tas;Tren hijab']],
'Food & Travel Creator':[
['🍜','Review Kuliner Lokal','Warung;Kafe;Kaki lima;Restoran keluarga;Kuliner pagi'],
['🌃','Street Food Tour','Jajanan malam;Pasar pagi;Gang kuliner;Es dan minuman;Camilan'],
['🥘','Resep Praktis','Masakan 15 menit;Menu hemat;Sarapan;Bekal;Minuman'],
['🗓️','Itinerary Wisata','Satu hari;Akhir pekan;Hemat;Keluarga;Solo'],
['💎','Hidden Gem','Pantai tersembunyi;Kafe tersembunyi;Air terjun;Desa wisata;Spot foto'],
['🏨','Staycation dan Hotel','Kamar;Fasilitas;Sarapan;Kolam;Pemandangan'],
['🧳','Travel Tips','Packing;Transportasi;Anggaran;Keamanan;Foto perjalanan'],
['☕','Kopi dan Kafe','Kopi lokal;Kafe estetik;Barista;Menu baru;Suasana'],
['🎁','Oleh-oleh','Makanan khas;Kerajinan;Pasar;Kemasan;Hadiah'],
['🍚','Kuliner dan Tradisi','Makanan hari raya;Adat makan;Menu keluarga;Kuliner tradisional;Minuman tradisional']],
'Brand Campaign':[
['📣','Brand Awareness','Kenalan dengan brand;Nilai brand;Cerita brand;Identitas visual;Pesan utama'],
['🚀','Peluncuran Produk','Teaser;Reveal produk;Fitur utama;Harga;Ajakan membeli'],
['🎄','Campaign Musiman','Ramadan;Akhir tahun;Tahun ajaran baru;Hari Kemerdekaan;Liburan'],
['🏭','Brand Story','Asal brand;Pendiri;Proses pembuatan;Komitmen;Komunitas'],
['🤳','Kolaborasi Kreator','Kreator mikro;Challenge;Giveaway;Live;Ulasan kreator'],
['🏷️','Promo dan Diskon','Flash sale;Bundle;Voucher;Gratis ongkir;Paket spesial'],
['💬','Bukti Sosial Etis','Pertanyaan pelanggan;Cerita pengguna nyata;Perbandingan;Highlight ulasan;Testimoni asli'],
['📘','Edukasi Produk','Cara pakai;Bahan;Perawatan;FAQ;Tips'],
['🎖️','Loyalty dan Komunitas','Keanggotaan;Poin;Event;Hadiah;Survei'],
['🔁','Pengingat dan CTA','Pengingat;Keranjang tertinggal;Penawaran;Ulasan asli;Penutup']]
}};
const BRAIN_ANGLES={
drama:[
 (s,u)=>['Cerita pendek: '+s,`Kisah satu adegan berpusat pada "${s}" dalam tema ${u}, dengan konflik yang jelas.`,'Satu kejadian kecil mengubah segalanya.','Pembuka → konflik → puncak → penutup'],
 (s,u)=>['Plot twist: '+s,`Cerita "${s}" (${u}) yang tampak biasa lalu berbalik di akhir.`,'Tidak ada yang menyangka akhirnya begini.','Setup biasa → petunjuk halus → twist'],
 (s,u)=>['Cliffhanger: '+s,`Bagian pembuka serial pendek berbasis "${s}" yang berhenti di momen genting.`,'Lalu pintu itu terbuka...','Perkenalan → eskalasi → cliffhanger'],
 (s,u)=>['Dua sudut pandang: '+s,`Satu kejadian "${s}" diceritakan dari dua tokoh dengan kebenaran yang berbeda.`,'Mereka mengalami hal yang sama, tapi ceritanya berbeda.','Versi A → versi B → kebenaran'],
 (s,u)=>['Satu malam: '+s,`Seluruh cerita "${s}" terjadi dalam satu malam dengan tensi meningkat.`,'Malam itu mengubah hidup mereka.','Sore → tengah malam → fajar'],
 (s,u)=>['Flashback: '+s,`Cerita "${s}" yang dibuka dari masa kini lalu menengok masa lalu penyebabnya.`,'Semua bermula dari hari itu.','Kini → kilas balik → kini yang berubah'],
 (s,u)=>['Tanpa dialog: '+s,`Cerita visual "${s}" yang disampaikan lewat ekspresi, gerak, dan suasana.`,'Tak ada yang bicara, tapi semuanya terasa.','Visual pembuka → emosi → klimaks visual'],
 (s,u)=>['Surat dan pesan: '+s,`Cerita "${s}" yang dipandu oleh surat atau pesan yang mengubah arah hubungan tokoh.`,'Pesan itu datang di waktu yang salah.','Pesan diterima → reaksi → keputusan'],
 (s,u)=>['Pilihan sulit: '+s,`Tokoh utama harus memilih dalam kisah "${s}" dan menanggung akibatnya.`,'Ia hanya punya satu menit untuk memutuskan.','Dilema → pilihan → akibat'],
 (s,u)=>['Pertemuan kembali: '+s,`Dua tokoh bertemu lagi dalam "${s}" setelah waktu yang lama.`,'Sudah lama sekali sejak terakhir kali.','Pertemuan → canggung → penyelesaian'],
 (s,u)=>['Rahasia terbongkar: '+s,`Rahasia di balik "${s}" terungkap dan mengubah hubungan antar tokoh.`,'Ada yang selama ini disembunyikan.','Petunjuk → pengungkapan → dampak'],
 (s,u)=>['Titik balik: '+s,`Momen ketika tokoh dalam "${s}" mengubah arah hidupnya.`,'Dari sinilah semuanya berubah.','Kondisi awal → pemicu → perubahan'],
 (s,u)=>['Salah paham: '+s,`Kesalahpahaman bermula dari "${s}" dan memuncak sebelum diluruskan.`,'Andai saja ia mau mendengarkan.','Insiden → salah tafsir → klarifikasi'],
 (s,u)=>['Pengorbanan: '+s,`Tokoh mengorbankan sesuatu yang berharga dalam kisah "${s}".`,'Ia rela melepaskan segalanya.','Harapan → pengorbanan → makna'],
 (s,u)=>['Detik terakhir: '+s,`Ketegangan di menit-menit terakhir pada kisah "${s}".`,'Tinggal beberapa detik lagi.','Hitung mundur → puncak → hasil'],
 (s,u)=>['Awal mula: '+s,`Kisah asal-usul yang menjelaskan bagaimana "${s}" berawal.`,'Tak ada yang tahu kapan semuanya dimulai.','Awal → perkembangan → keadaan kini'],
 (s,u)=>['Bagian lanjutan: '+s,`Lanjutan dari kisah "${s}" dengan konflik baru yang lebih besar.`,'Ternyata ceritanya belum selesai.','Ringkasan → konflik baru → janji bagian berikutnya'],
 (s,u)=>['Akhir terbuka: '+s,`Cerita "${s}" yang berakhir tanpa jawaban pasti agar penonton berdiskusi.`,'Menurutmu, apa yang terjadi setelah itu?','Cerita → keputusan → akhir terbuka'],
 (s,u)=>['Akhir hangat: '+s,`Cerita "${s}" dengan penyelesaian hangat dan menenangkan.`,'Akhirnya semuanya menemukan jalannya.','Konflik → rekonsiliasi → harapan'],
 (s,u)=>['Pesan moral: '+s,`Cerita "${s}" yang ditutup dengan pelajaran yang membekas.`,'Dari kejadian ini ada satu pelajaran penting.','Cerita → refleksi → pesan']],
affiliate:[
 (s,u)=>['Masalah yang diselesaikan oleh '+s,`Konten yang membuka dari masalah sehari-hari (${u}) lalu memperlihatkan cara ${s} membantu.`,'Pernah mengalami hal ini?','Masalah → solusi → demo → CTA'],
 (s,u)=>['Demo '+s+' dalam 15 detik',`Demonstrasi cepat fungsi utama ${s} dengan visual jelas.`,'Lihat cara kerjanya dalam 15 detik.','Hook → demo → hasil → CTA'],
 (s,u)=>['Sebelum dan sesudah memakai '+s,`Perbandingan visual kondisi sebelum dan sesudah memakai ${s}, tanpa klaim berlebihan.`,'Bedanya bisa dilihat langsung.','Kondisi awal → pemakaian → perbandingan'],
 (s,u)=>['3 alasan '+s+' layak dipertimbangkan',`Tiga alasan praktis memilih ${s} dalam kategori ${u}.`,'Tiga alasan ini membuatku ingin mencobanya.','Hook → alasan 1–3 → CTA'],
 (s,u)=>['Kesalahan saat memilih '+s,`Kesalahan umum ketika membeli ${s} dan cara menghindarinya.`,'Jangan beli sebelum tahu ini.','Kesalahan → dampak → tips memilih'],
 (s,u)=>['Cara memakai '+s+' paling praktis',`Panduan langkah singkat memakai ${s} dengan benar.`,'Cukup tiga langkah mudah.','Siapkan → langkah 1–3 → hasil'],
 (s,u)=>['Detail kecil '+s+' yang sering terlewat',`Menyoroti detail pada ${s} yang jarang diperhatikan pembeli.`,'Perhatikan detail kecil ini.','Gambaran umum → zoom detail → manfaat'],
 (s,u)=>[s+' cocok untuk siapa?',`Mengenali tipe pengguna yang paling terbantu oleh ${s}.`,'Cocok tidaknya tergantung kebutuhanmu.','Profil pengguna → alasan → CTA'],
 (s,u)=>['Unboxing '+s+' fokus detail',`Membuka kemasan ${s} sambil memperlihatkan isi, material, dan kelengkapan.`,'Isinya ternyata begini.','Kemasan → isi → detail → kesan'],
 (s,u)=>['Checklist sebelum membeli '+s,`Daftar periksa praktis sebelum membeli ${s}.`,'Cek dulu lima hal ini.','Checklist 1–5 → rekomendasi'],
 (s,u)=>['Mitos dan fakta tentang '+s,`Meluruskan anggapan umum tentang ${s} secara jujur.`,'Benarkah begitu?','Mitos → fakta → saran'],
 (s,u)=>[s+' dalam rutinitas sehari-hari',`Memperlihatkan ${s} dalam aktivitas harian yang realistis.`,'Begini caraku memakainya setiap hari.','Pagi → siang → malam → CTA'],
 (s,u)=>['Perbandingan pilihan '+s,`Membandingkan beberapa tipe ${s} berdasarkan kebutuhan, bukan klaim berlebihan.`,'Mana yang paling cocok untukmu?','Kriteria → perbandingan → rekomendasi'],
 (s,u)=>['Tips merawat '+s+' agar awet',`Cara merawat ${s} supaya tahan lama.`,'Dengan cara ini pemakaiannya bisa lebih lama.','Masalah umum → perawatan → hasil'],
 (s,u)=>['FAQ calon pembeli '+s,`Menjawab pertanyaan yang sering muncul tentang ${s}.`,'Pertanyaan ini paling sering ditanyakan.','Pertanyaan 1–3 → jawaban → CTA'],
 (s,u)=>[s+' sebagai ide hadiah',`Menampilkan ${s} sebagai pilihan hadiah beserta alasannya.`,'Bingung cari hadiah?','Kebutuhan → ide hadiah → CTA'],
 (s,u)=>['Skenario penggunaan nyata '+s,`Situasi nyata di mana ${s} berguna.`,'Ini situasi di mana aku paling terbantu.','Situasi → penggunaan → manfaat'],
 (s,u)=>['Fitur unggulan '+s+' secara visual',`Visualisasi fitur utama ${s} dengan animasi sederhana.`,'Inilah fitur yang paling menarik perhatian.','Fitur → visual → manfaat'],
 (s,u)=>['Worth it atau tidak? Menimbang '+s,`Menimbang manfaat, harga, dan kebutuhan terkait ${s} secara seimbang.`,'Sebelum checkout, pertimbangkan ini.','Manfaat → kekurangan → kesimpulan'],
 (s,u)=>['CTA lembut: '+s,`Konten santai tentang ${s} dengan ajakan halus untuk melihat produk.`,'Kalau kamu butuh, cek di link ya.','Cerita ringan → manfaat → CTA lembut']],
influencer:[
 (s,u)=>['Kenalan lewat '+s,`Influencer virtual memperkenalkan diri melalui topik "${s}" (${u}).`,'Halo, kenalan dulu yuk!','Sapa → cerita → ajakan mengikuti'],
 (s,u)=>['Sehari bersama '+s,`Mini vlog yang mengikuti hari karakter dengan fokus "${s}".`,'Ikuti hariku, mulai dari pagi.','Pagi → aktivitas → malam'],
 (s,u)=>['Rahasia kecil '+s,`Berbagi trik atau rahasia ringan seputar "${s}".`,'Ini hal kecil yang jarang dibagikan.','Teaser → rahasia → manfaat'],
 (s,u)=>['Tantangan '+s,`Format tantangan singkat yang melibatkan "${s}" dan mengajak penonton ikut.`,'Berani coba tantangan ini?','Aturan → aksi → ajakan ikut'],
 (s,u)=>['Tanya jawab seputar '+s,`Menjawab pertanyaan audiens tentang "${s}".`,'Kalian tanya, aku jawab.','Pertanyaan → jawaban → ajakan bertanya'],
 (s,u)=>['Reaksi pertama pada '+s,`Reaksi spontan karakter saat pertama kali menemui "${s}".`,'Aku nggak nyangka hasilnya begini.','Ekspektasi → reaksi → kesan'],
 (s,u)=>['Tutorial singkat '+s,`Panduan ringkas berbasis "${s}" dengan langkah mudah diikuti.`,'Ikuti tiga langkah ini.','Siapkan → langkah → hasil'],
 (s,u)=>['Behind the scene '+s,`Memperlihatkan proses di balik layar "${s}".`,'Ini yang terjadi di balik layar.','Persiapan → proses → hasil akhir'],
 (s,u)=>['Cerita di balik '+s,`Narasi pribadi karakter tentang "${s}" yang membangun kedekatan dengan audiens.`,'Ada cerita menarik di balik ini.','Pembuka → cerita → pesan'],
 (s,u)=>['Rekomendasi pribadi: '+s,`Rekomendasi jujur berbasis "${s}" yang disampaikan hangat dan berlabel iklan bila bekerja sama.`,'Ini yang menurutku layak dicoba.','Alasan → contoh → CTA lembut'],
 (s,u)=>['Kesalahan umum soal '+s,`Menyoroti kesalahan umum seputar "${s}" dan cara memperbaikinya.`,'Jangan lakukan ini lagi.','Kesalahan → solusi → ajakan'],
 (s,u)=>['Perbandingan: '+s,`Membandingkan dua pilihan terkait "${s}" dengan penjelasan seimbang.`,'Mana yang lebih cocok untukmu?','Pilihan A → pilihan B → saran'],
 (s,u)=>['Tips cepat '+s,`Tips singkat 20–30 detik tentang "${s}".`,'Satu tips yang bisa langsung dipakai.','Hook → tips → CTA'],
 (s,u)=>['Transformasi: '+s,`Perubahan bertahap yang terkait dengan "${s}", ditampilkan secara realistis.`,'Lihat perubahannya dari awal.','Awal → proses → hasil'],
 (s,u)=>['Mini vlog: '+s,`Vlog singkat bergaya santai dengan tema "${s}".`,'Ayo ikut aku hari ini.','Pembuka → momen → penutup'],
 (s,u)=>['Mitos tentang '+s,`Meluruskan anggapan umum terkait "${s}".`,'Katanya begitu, benarkah?','Mitos → fakta → saran'],
 (s,u)=>['Highlight '+s,`Menyoroti momen terbaik dari "${s}" dalam format ringkas.`,'Ini bagian yang paling menarik.','Cuplikan → sorotan → ajakan'],
 (s,u)=>['Hook stop-scroll: '+s,`Video pendek dengan pembuka kuat berbasis "${s}".`,'Tunggu, jangan scroll dulu!','Hook → inti → CTA'],
 (s,u)=>['Kolaborasi: '+s,`Konsep kolaborasi karakter atau brand dengan tema "${s}".`,'Hari ini aku kedatangan tamu spesial.','Perkenalan → kolaborasi → ajakan'],
 (s,u)=>['Ajakan interaksi: '+s,`Konten yang mengajak penonton berkomentar atau memilih terkait "${s}".`,'Tim mana kamu? Tulis di komentar.','Pertanyaan → opsi → ajakan komentar']]
};
const BRAIN_VERIFY={
 drama:' · Catatan: pertahankan karakter, konflik, dan nada yang sama di seluruh scene; hindari adegan kekerasan eksplisit.',
 affiliate:' · Catatan: pastikan klaim sesuai spesifikasi resmi produk, tanpa janji hasil berlebihan; beri label iklan/afiliasi dan jangan menampilkan brand tanpa izin.',
 influencer:' · Catatan: tampilkan sebagai karakter virtual/iklan dengan label yang jelas; jangan membuat testimoni palsu atas nama orang nyata.'
};
function brainSubOptions(moduleId,catName){
 const m=BRAIN_SUBS[moduleId];if(!m)return null;const k=stripEmoji(catName);const list=m[k];
 return list?list.map(x=>x[0]+' '+x[1]):null;
}
function brainIdeas(moduleId,catName,subName){
 const m=BRAIN_SUBS[moduleId];const angles=BRAIN_ANGLES[moduleId];const verify=BRAIN_VERIFY[moduleId]||'';
 const cat=stripEmoji(catName);const clean=stripEmoji(subName);
 const list=(m&&m[cat])||null;const idx=list?list.findIndex(x=>x[1]===clean):-1;
 const seeds=idx>=0?list[idx][2].split(';'):null;
 const out=[];
 for(let i=0;i<20;i++){
  const subj=seeds?seeds[(i+idx)%seeds.length]:clean;
  const a=angles[i](subj,clean);
  out.push(`💡 ${String(i+1).padStart(2,'0')}. ${a[0]}||${a[1]}||${a[2]}||${a[3]}${verify}`);
 }
 return out;
}
/* OTAK untuk ChatGPT: instruksi per studio + alur terkunci */
const MODULE_BRAINS={
 animation:'OTAK ANIMATION STUDIO: Kamu menulis konten fakta/edukasi/wisata/hewan/sejarah/horor-ringan untuk video animasi pendek. Ikuti jalur terkunci: studio → kategori layar 1 → kategori layar 2 → ide layar 3. Jangan melompat ke kategori lain. Fakta harus dapat diverifikasi; legenda dan misteri disajikan sebagai cerita atau teori, bukan fakta pasti, tanpa gore.',
 drama:'OTAK DRAMA AI: Kamu adalah penulis dan sutradara short drama. Ikuti jalur terkunci: Drama → genre (layar 1) → tema (layar 2) → ide cerita (layar 3). Jaga genre dan nada. Bangun karakter, tujuan, konflik, titik balik, dialog natural, dan hook episode berikutnya. Setiap scene harus menyambung secara sebab-akibat dengan scene sebelumnya. Hindari kekerasan eksplisit.',
 affiliate:'OTAK AFFILIATE AI: Kamu adalah strategis konten afiliasi. Ikuti jalur terkunci: Affiliate → kategori produk (layar 1) → jenis produk (layar 2) → angle konten (layar 3). Gunakan struktur hook → masalah → demo/manfaat → CTA. Jangan membuat klaim medis, hasil pasti, atau spesifikasi yang belum terverifikasi. Gunakan label iklan/afiliasi dan jangan mengarang nama brand, harga, atau testimoni.',
 influencer:'OTAK AI INFLUENCER & ADS: Kamu adalah creative director untuk influencer virtual dan iklan produk. Ikuti jalur terkunci: Influencer & Ads → kategori (layar 1) → arah (layar 2) → ide konten (layar 3). Pertahankan persona, gaya bicara, wardrobe, dan lokasi karakter yang konsisten di setiap scene. Format UGC/ads harus berlabel jelas sebagai karakter virtual atau iklan; jangan membuat testimoni palsu atas nama orang nyata.'
};
/* Tambahan v1.3.3: setiap kategori layar 1 kini memiliki 12 arah di layar 2 (sama seperti Animation Studio). */
const BRAIN_EXTRA={
drama:{
'Romance':[['🎶','Romansa Lewat Hobi','Klub musik kampus;Kelas memasak;Komunitas fotografi;Teman mendaki;Kelas menari'],['🎁','Kejutan dan Momen Spesial','Ulang tahun rahasia;Lamaran sederhana;Hadiah yang tertukar;Kencan di atap;Makan malam tak terduga']],
'Thriller & Misteri':[['🏢','Misteri di Tempat Kerja','Dokumen yang hilang;Ruang arsip terkunci;Rekan yang menghilang;Email janggal;Lift berhenti di lantai kosong'],['🎓','Misteri di Sekolah dan Kampus','Soal ujian bocor;Buku harian tertinggal;Kunci laboratorium;Loker yang berpindah;Pengumuman tanpa nama']],
'Horor':[['🌊','Horor Laut dan Pantai','Pantai saat senja;Perahu tanpa awak;Suara dari dermaga;Mercusuar tua;Jejak kaki di pasir'],['🏥','Horor Tempat Umum','Rumah sakit tua;Stasiun malam hari;Pasar sepi;Toilet umum;Bioskop kosong']],
'Komedi':[['🍜','Komedi Kuliner','Warung salah pesanan;Resep gagal;Lomba makan;Dapur kos;Nasi goreng spesial'],['✈️','Komedi Perjalanan','Salah naik kereta;Koper tertukar;Penginapan salah pesan;Tur yang kacau;Ketinggalan pesawat']],
'Melodrama Keluarga':[['💔','Perpisahan dan Kehilangan','Pamit di stasiun;Rumah yang kosong;Kenangan dalam foto;Pesan terakhir;Hari pertama tanpa dia'],['🤗','Persahabatan dan Keluarga Pilihan','Sahabat seperti saudara;Tetangga yang menolong;Teman seperjuangan;Panti dan keluarga baru;Rumah kos yang hangat']],
'Action & Petualangan':[['🚁','Misi Ekstrem','Terjebak di lembah;Penyelamatan helikopter;Menyeberangi jurang;Badai di puncak;Misi sebelum fajar'],['🧭','Petualangan Pelajar dan Remaja','Perkemahan sekolah;Peta rahasia di sekolah;Geng penjelajah;Lomba orienteering;Gua di belakang desa']]},
affiliate:{
'Beauty & Skincare':[['🧖','Perawatan di Rumah','Spa di rumah;Masker malam;Mandi aromaterapi;Perawatan akhir pekan;Rutinitas santai'],['🧳','Kecantikan Saat Bepergian','Ukuran travel;Pouch anti tumpah;Perawatan di pesawat;Makeup ringkas;Kit darurat kecantikan']],
'Fashion & Aksesori':[['🏃','Fashion Olahraga dan Aktif','Legging;Sepatu olahraga;Jaket ringan;Topi lari;Tas gym'],['🌧️','Fashion Musiman','Outer musim hujan;Pakaian tipis;Syal;Sandal pantai;Payung stylish']],
'Home & Kitchen':[['🎄','Dekorasi Musiman','Lampu hias;Dekor Ramadan;Dekor akhir tahun;Hiasan dinding;Taplak meja'],['🏘️','Hunian Kecil dan Kos','Rak lipat;Kasur lipat;Penyimpanan vertikal;Peralatan masak mini;Lampu hemat ruang']],
'Gadget & Teknologi':[['🚗','Gadget Kendaraan','Holder mobil;Dashcam;Charger mobil;Pembersih kabin;Pelacak motor'],['🎓','Gadget Pelajar dan Mahasiswa','Tablet;Stylus;Kalkulator;Headset belajar;Tas laptop']],
'Daily-use Products':[['🍱','Kebutuhan Dapur Harian','Kantong sampah;Spons cuci;Tisu dapur;Kotak penyimpanan;Pembersih piring'],['💼','Kebutuhan Pelajar dan Pekerja','Tas bekal;Botol minum;Payung kecil;Organizer tas;Gantungan ID']],
'Family & Baby':[['🩺','Kebersihan Anak','Sabun anak;Sikat gigi anak;Pengukur suhu;Tisu basah bayi;Handuk lembut'],['🏡','Rumah Ramah Anak','Karpet main;Rak mainan;Pagar pengaman;Meja belajar;Lampu kamar anak']]},
influencer:{
'Profil Influencer Virtual':[['🎬','Format Video Khas','Intro khas;Segmen tetap;Outro ikonik;Transisi khas;Musik latar khas'],['🛡️','Etika dan Transparansi Karakter','Label karakter virtual;Aturan iklan;Batas konten;Privasi;Gaya komunikasi aman']],
'Product Showcase':[['🧪','Uji Coba Produk','Tes ketahanan;Tes pemakaian harian;Tes fitur;Perbandingan sederhana;Catatan setelah seminggu'],['📸','Foto dan Video Produk Estetik','Flat lay;Close-up makro;Cahaya natural;Latar berwarna;Gerak lambat']],
'UGC & Review Berskrip':[['🛒','Alasan Membeli','Kebutuhan awal;Pertimbangan harga;Alasan memilih;Cara membandingkan;Keputusan akhir'],['🧠','Edukasi lewat Review','Fakta bahan;Cara pakai benar;Mitos umum;Tips merawat;Kesalahan pemula']],
'Lifestyle & Fashion':[['🏙️','Kota dan Aktivitas','Hari di kota;Jalan sore;Pasar akhir pekan;Kafe untuk kerja;Event lokal'],['🧘','Mindful Living','Rutinitas tenang;Jurnal harian;Pagi tanpa ponsel;Ruang rapi;Waktu istirahat']],
'Food & Travel Creator':[['🍰','Dessert dan Minuman','Es kekinian;Kue tradisional;Kopi susu;Teh;Dessert malam'],['🏕️','Outdoor dan Petualangan','Camping;Pendakian ringan;Pantai;Piknik;Sungai']],
'Brand Campaign':[['🎞️','Iklan Pendek Storytelling','Cerita 15 detik;Masalah harian;Momen emosional;Kejutan kecil;Penutup brand'],['📊','Kampanye Berbasis Data','Hasil survei;Tren pencarian;Kebiasaan konsumen;Perbandingan sederhana;Insight komunitas']]}
};
Object.keys(BRAIN_EXTRA).forEach(m=>Object.keys(BRAIN_EXTRA[m]).forEach(c=>BRAIN_SUBS[m][c].push(...BRAIN_EXTRA[m][c])));
