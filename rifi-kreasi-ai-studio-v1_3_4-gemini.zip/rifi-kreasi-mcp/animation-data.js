/* RiFi Kreasi · Animation Studio — data alur terkunci
   LAYAR 1: 6 kategori → LAYAR 2: 12 kategori per pilihan → LAYAR 3: 20 ide per pilihan.
   Layar 2 & 3 hanya diturunkan dari pilihan layar sebelumnya. */
const ANIM_CATS=[
 {key:'fakta',icon:'✨',name:'Fakta Menarik',desc:'Fakta unik, mengejutkan dan mudah dibagikan.'},
 {key:'wisata',icon:'🌴',name:'Wisata & Keindahan Alam',desc:'Destinasi, panorama dan keajaiban alam.'},
 {key:'edukasi',icon:'🧠',name:'Edukasi & Pengetahuan',desc:'Penjelasan sains, teknologi dan wawasan praktis.'},
 {key:'hewan',icon:'🐾',name:'Hewan & Kehidupan Alam',desc:'Satwa, ekosistem dan perilaku alam.'},
 {key:'sejarah',icon:'🏛️',name:'Sejarah & Budaya',desc:'Peristiwa, tradisi dan warisan budaya.'},
 {key:'horor',icon:'👻',name:'Horor & Misteri',desc:'Legenda, misteri dan cerita seram yang aman ditonton.'}
];
/* Format: [emoji, nama layar 2, "10 subjek spesifik dipisah ;"] */
const ANIM_SUBS={
fakta:[
['🌍','Fakta Menarik Wisata Dunia','Menara Eiffel yang memuai saat panas;Tembok Besar Tiongkok;Machu Picchu di atas awan;Venesia yang perlahan tenggelam;Taj Mahal dan perubahan warnanya;Santorini dan rumah putihnya;Gurun Sahara yang dulu hijau;Salju abadi di Swiss;Kota terapung Ha Long Bay;Colosseum Roma dan sistem lantainya'],
['🏝️','Fakta Menarik Wisata di Indonesia','Raja Ampat dan keragaman terumbu karangnya;Danau Toba bekas letusan super;Borobudur dan relief ribuan panelnya;Kawah Ijen dan api biru;Pulau Komodo;Bromo dan lautan pasir;Labuan Bajo dan pantai merah muda;Wakatobi dan surga selam;Bunaken dan dinding lautnya;Danau Kelimutu yang berubah warna'],
['🗺️','Fakta Menarik Daerah di Indonesia','Yogyakarta dan status istimewanya;Papua dan ratusan bahasa daerah;Bali dan hari Nyepi;Sumatra Barat dan sistem matrilineal;Toraja dan upacara adatnya;Maluku dan sejarah rempah;Aceh dan Serambi Mekkah;Kalimantan dan paru-paru dunia;Nusa Tenggara Timur dan savananya;Sulawesi Utara dan Bunaken'],
['🌋','Fakta Menarik Keajaiban Dunia','Piramida Giza dan presisi bangunannya;Petra si kota merah muda;Chichen Itza dan efek bunyinya;Cristo Redentor;Great Barrier Reef;Aurora Borealis;Grand Canyon;Gunung Everest;Air Terjun Victoria;Menara Pisa yang miring'],
['😂','Fakta Menarik Sejarah Lucu','Raja yang dilarang tertawa terlalu keras;Pajak jenggot di Rusia;Perang gara-gara ember;Tikus penggali yang jadi pahlawan;Perang burung emu Australia;Hukum aneh zaman kuno;Kebiasaan mandi para raja;Penemuan yang tidak sengaja;Presiden dan hewan peliharaan anehnya;Kesalahan peta paling konyol'],
['😱','Fakta Menarik Sejarah Menyeramkan','Wabah Black Death di Eropa;Kota Pompeii yang terkubur abu;Kutukan makam firaun;Benteng penjara berhantu;Ritual kuno yang mengerikan;Katakombe Paris;Kapal Mary Celeste yang kosong;Tambang yang runtuh dan legendanya;Desa terkutuk di Eropa;Letusan Krakatau 1883'],
['🐶','Fakta Menarik Hewan Lucu','Sidik hidung anjing yang unik;Berpegangan tangan ala berang-berang laut;Quokka si hewan tersenyum;Kucing dan suara mengeong;Panda yang suka bergulingan;Kukang dan gerakannya;Penguin melamar dengan batu;Kelinci yang melompat gembira;Lumba-lumba dan nama panggilan;Bayi gajah dan belalainya'],
['🩺','Fakta Menarik Kesehatan','Tidur dan daya ingat otak;Air putih dan konsentrasi;Jalan kaki 30 menit;Senyum dan hormon bahagia;Sarapan dan energi harian;Postur duduk dan nyeri punggung;Kebiasaan mencuci tangan;Cahaya matahari dan vitamin D;Stres dan tubuh;Mitos kesehatan yang keliru'],
['🧬','Fakta Menarik Tubuh Manusia','Jantung yang tidak pernah istirahat;Otak dan jutaan sel saraf;Tulang yang lebih kuat dari baja;Kulit yang selalu memperbarui diri;Mata dan cara melihat warna;Lidah dan sidik uniknya;Usus dan mikrobioma;Darah dan perjalanannya;Tangan dan ribuan sensor;Mimpi saat tidur'],
['🔬','Fakta Menarik Sains & Teknologi','Internet bawah laut;Ponsel dan daya komputasinya;GPS dan teori relativitas;Listrik statis;Magnet raksasa;Robot yang belajar berjalan;Kecerdasan buatan sehari-hari;Satelit di atas kepala;Baterai dan cara kerjanya;Kembaran digital kota'],
['🚀','Fakta Menarik Luar Angkasa','Hari di Venus lebih panjang dari tahunnya;Hujan berlian di Neptunus;Matahari dan ukurannya;Lubang hitam;Bulan yang menjauh dari Bumi;Cincin Saturnus;Astronot dan tinggi badan;Bintang jatuh;Mars dan langit birunya saat senja;Cahaya yang menempuh jutaan tahun'],
['🍜','Fakta Menarik Makanan & Kuliner','Madu yang nyaris tidak basi;Cabai dan rasa pedas;Cokelat dan asal-usulnya;Rendang dan proses panjangnya;Kopi dan kisah penemunya;Tempe dan warisan Nusantara;Garam yang pernah jadi alat tukar;Pizza dan sejarahnya;Mi dan perjalanannya;Teh dan ritual minum teh']],
wisata:[
['🏖️','Pantai & Pulau Tropis','Pantai pasir merah muda;Pulau terpencil Maluku;Pantai dengan pasir berbunyi;Laguna biru tersembunyi;Pulau karang Wakatobi;Pantai bioluminesens;Gugusan pulau Raja Ampat;Teluk sunyi Nusa Tenggara;Pantai berbatu karang raksasa;Pulau pasir yang muncul saat surut'],
['⛰️','Gunung & Pendakian','Puncak di atas lautan awan;Gunung dengan danau kawah;Jalur savana yang luas;Sunrise dari puncak gunung;Padang edelweis;Gunung berapi aktif yang aman dikagumi;Bukit teletubbies;Perkemahan di tepi danau gunung;Gunung dengan tebing curam;Jalur pendakian ramah pemula'],
['💦','Air Terjun Tersembunyi','Air terjun bertingkat;Air terjun di tengah hutan;Air terjun dengan kolam biru;Air terjun tertinggi di Indonesia;Air terjun yang jatuh ke laut;Air terjun kembar;Air terjun dalam gua;Air terjun pelangi;Air terjun di tepi tebing;Jalur trekking menuju air terjun'],
['🏞️','Danau & Sungai Menakjubkan','Danau tiga warna;Danau di dalam kawah;Danau vulkanik terbesar;Sungai bercahaya biru;Sungai jernih berbatu;Danau di ketinggian;Sungai di tengah hutan hujan;Arung jeram yang seru;Danau yang mengambang;Pasar terapung sungai'],
['🌳','Hutan & Taman Nasional','Hutan hujan tropis;Taman nasional dengan harimau;Hutan bakau;Pohon raksasa berusia ratusan tahun;Jembatan kanopi hutan;Hutan lumut;Savana taman nasional;Hutan pinus berkabut;Hutan tropis pegunungan;Pengamatan satwa liar'],
['🏡','Desa Wisata & Kearifan Lokal','Desa adat tradisional;Desa di lereng gunung;Desa nelayan berwarna-warni;Desa terapung;Desa tenun;Desa kopi;Homestay di tepi sawah;Desa budaya tanpa kendaraan;Desa kerajinan perak;Desa di atas awan'],
['✈️','Destinasi Dunia yang Wajib Dikunjungi','Kyoto saat musim sakura;Islandia dan air terjun;Swiss dan pegunungan Alpen;Maladewa dan vila air;Norwegia dan fjord;Selandia Baru;Patagonia;Santorini;Dolomites Italia;Kepulauan Faroe'],
['💎','Surga Tersembunyi Indonesia','Pulau terpencil di Maluku Utara;Air terjun tersembunyi Flores;Kampung di atas awan;Pantai sepi di Sumba;Danau biru di pedalaman;Gua kristal;Pulau Padar;Hutan kabut di Papua;Pantai karang di Belitung;Savana Sumba'],
['🐠','Keindahan Bawah Laut','Taman terumbu karang;Kura-kura hijau;Penyu dan sarangnya;Gua laut biru;Ikan pari manta;Padang lamun;Hiu paus;Kapal karam yang jadi rumah ikan;Dinding laut Bunaken;Spot snorkeling ramah pemula'],
['🕳️','Gua & Formasi Batuan Unik','Gua stalaktit dan stalagmit;Gua sungai bawah tanah;Gua cahaya;Formasi batuan karst;Gua dengan lukisan prasejarah;Tebing kapur;Gua kristal es;Kolam alami di gua;Pegunungan karst Maros;Lembah dengan bebatuan unik'],
['🌅','Sunrise, Sunset & Langit Malam','Sunrise di Bromo;Sunset di tepi pantai;Langit bertabur bintang;Aurora yang menari;Milky Way di Sumba;Golden hour di sawah;Lautan awan pagi hari;Cahaya senja di danau;Bulan purnama di pantai;Pelangi di air terjun'],
['🍲','Wisata Kuliner Daerah','Pasar tradisional pagi hari;Makanan khas pesisir;Kuliner gunung dan dataran tinggi;Jajanan kaki lima legendaris;Warung kopi tradisional;Sarapan khas daerah;Makanan khas Manado;Kuliner Sumatra;Dapur tradisional kampung;Manisan dan kue basah khas daerah']],
edukasi:[
['🧪','Sains Sehari-hari','Mengapa langit biru;Mengapa es mengapung;Bagaimana pelangi terbentuk;Mengapa kita menguap;Bagaimana magnet bekerja;Mengapa petir dan guntur berbeda waktu;Bagaimana sabun membersihkan;Mengapa balon melayang;Bagaimana lensa memperbesar;Mengapa laut terasa asin'],
['🫀','Tubuh Manusia','Cara kerja jantung;Cara otak menyimpan memori;Cara tubuh melawan kuman;Cara mata melihat;Cara paru-paru bernapas;Cara tulang tumbuh;Cara pencernaan bekerja;Cara telinga mendengar;Cara tubuh mengatur suhu;Cara tidur memulihkan tubuh'],
['🪐','Luar Angkasa & Tata Surya','Urutan planet;Bagaimana bintang lahir;Mengapa bulan punya fase;Cara roket meluncur;Apa itu lubang hitam;Bagaimana gerhana terjadi;Mengapa Pluto bukan planet;Gravitasi dan orbit;Hidup di stasiun luar angkasa;Galaksi dan jarak antar bintang'],
['🤖','Teknologi & Kecerdasan Buatan','Apa itu AI;Cara kerja internet;Bagaimana GPS menemukan lokasi;Apa itu cloud;Cara kerja kamera ponsel;Apa itu enkripsi;Cara kerja baterai;Apa itu blockchain secara sederhana;Cara kerja WiFi;Robot dalam kehidupan sehari-hari'],
['➗','Matematika Seru','Pola bilangan Fibonacci di alam;Angka nol dan sejarahnya;Probabilitas koin;Trik berhitung cepat;Pi dan lingkaran;Simetri dalam bangunan;Bilangan prima;Paradoks ulang tahun;Geometri dalam sarang lebah;Logika teka-teki'],
['🧠','Psikologi & Perilaku Manusia','Bias kebiasaan;Efek placebo;Cara otak membentuk kebiasaan;Mengapa kita menunda pekerjaan;Efek kehadiran orang lain;Memori palsu;Psikologi warna;Cara membaca bahasa tubuh;Efek fokus dan distraksi;Mengelola emosi'],
['🧭','Geografi & Peta','Mengapa peta dunia tampak berbeda;Garis khatulistiwa;Zona waktu;Lempeng tektonik;Cincin api Pasifik;Negara kepulauan terbesar;Sungai terpanjang;Gurun dan hutan dunia;Benua dan samudra;Musim di berbagai belahan dunia'],
['🔤','Bahasa & Kata','Asal-usul kata dalam Bahasa Indonesia;Bahasa dengan huruf unik;Bahasa daerah yang terancam;Kata serapan;Kata yang tidak bisa diterjemahkan;Idiom dan peribahasa;Bahasa isyarat;Mengapa aksen berbeda;Sejarah huruf;Kata baru yang lahir dari internet'],
['💰','Ekonomi & Literasi Uang','Apa itu inflasi;Cara kerja bunga majemuk;Menabung dan investasi;Asal-usul uang;Dana darurat;Utang produktif dan konsumtif;Kenapa harga berubah;Cara kerja bank;Mata uang dan nilai tukar;Kebiasaan finansial sehat'],
['🌱','Lingkungan & Perubahan Iklim','Efek rumah kaca;Daur ulang sampah;Es kutub yang mencair;Energi terbarukan;Hutan dan oksigen;Plastik di laut;Banjir dan resapan air;Polusi udara;Jejak karbon;Pertanian ramah lingkungan'],
['🍎','Kesehatan & Gaya Hidup','Gizi seimbang;Manfaat olahraga ringan;Pentingnya hidrasi;Cara tidur berkualitas;Kesehatan mata di era layar;Menjaga kesehatan mental;Cara mencuci tangan yang benar;Bahaya duduk terlalu lama;Mengenal vitamin;Kebiasaan sehat pagi hari'],
['📚','Tips Belajar & Produktivitas','Teknik Pomodoro;Metode Feynman;Cara mencatat efektif;Teknik mengingat dengan kisah;Kebiasaan belajar yang efektif;Mengatur waktu;Mengatasi rasa malas;Belajar dengan pengulangan berjarak;Fokus di era notifikasi;Membangun kebiasaan kecil']],
hewan:[
['🐼','Hewan Lucu & Menggemaskan','Anak panda yang bermain;Berang-berang laut berpegangan tangan;Quokka yang tersenyum;Anak kucing hutan;Musang kecil yang penasaran;Anak gajah dan belalainya;Alpaka berbulu tebal;Kukang yang pemalu;Bayi koala;Hamster dan pipi penampungnya'],
['🦏','Hewan Langka & Terancam Punah','Badak Jawa;Harimau Sumatra;Orangutan Kalimantan;Elang Jawa;Komodo;Penyu belimbing;Gajah Sumatra;Trenggiling;Macan tutul Jawa;Burung Cendrawasih'],
['🐙','Hewan Laut & Samudra','Gurita dan kecerdasannya;Paus biru;Hiu paus;Ubur-ubur abadi;Kuda laut jantan yang mengandung;Ikan pari manta;Penyu hijau;Lumba-lumba;Anglerfish di laut dalam;Kepiting kelapa'],
['🦜','Burung & Dunia Penerbangan','Burung hantu;Elang dan pandangan tajamnya;Cendrawasih menari;Burung kolibri;Penguin dan cara bertahan;Burung walet;Burung unta;Bangau;Burung beo yang meniru suara;Migrasi burung ribuan kilometer'],
['🐝','Serangga & Dunia Mikro','Lebah dan tarian komunikasi;Semut dan koloni raksasa;Kupu-kupu dan metamorfosis;Kunang-kunang;Belalang sembah;Jangkrik dan suaranya;Capung;Kumbang badak;Rayap;Laba-laba dan jaringnya'],
['🦎','Reptil & Amfibi','Komodo;Bunglon dan perubahan warnanya;Katak beracun;Ular piton;Buaya;Kura-kura raksasa;Salamander;Cicak dan tapak lengketnya;Kadal terbang;Katak pohon'],
['🦁','Predator Puncak','Singa dan kawanannya;Harimau dan teritorinya;Beruang kutub;Elang pemburu;Hiu putih;Macan tutul;Buaya muara;Serigala;Orca;Komodo'],
['🧠','Hewan Paling Cerdas','Gagak dan alat bantu;Gurita yang membuka toples;Simpanse;Lumba-lumba;Gajah yang berduka;Anjing yang memahami kata;Burung beo;Orangutan;Lebah dan angka;Tikus dan empati'],
['🇮🇩','Satwa Endemik Indonesia','Anoa Sulawesi;Tarsius si primata mungil;Babirusa;Burung maleo;Orangutan Tapanuli;Jalak Bali;Komodo;Kasuari;Monyet hitam Sulawesi;Rangkong gading'],
['🐕','Hewan Peliharaan & Perilakunya','Mengapa kucing mendengkur;Anjing yang menggoyangkan ekor;Kelinci dan telinga panjangnya;Hamster aktif di malam hari;Burung kicau;Ikan hias;Kucing yang jatuh dengan kaki;Anjing penolong;Kura-kura peliharaan;Cara memahami bahasa tubuh hewan'],
['🧭','Migrasi, Insting & Kemampuan Bertahan','Migrasi wildebeest;Penyu kembali ke pantai kelahiran;Kupu-kupu raja;Salmon melawan arus;Burung walet;Paus bermigrasi;Semut dan pembagian tugas;Hibernasi beruang;Bunglon menyamar;Kamuflase gurita'],
['🌿','Hutan, Savana & Ekosistem','Rantai makanan;Hutan hujan tropis;Terumbu karang;Hutan bakau;Savana Afrika;Sungai Amazon;Padang lamun;Hutan pegunungan berkabut;Danau dan satwanya;Peran lebah untuk tanaman']],
sejarah:[
['👑','Kerajaan & Kesultanan Nusantara','Sriwijaya dan jalur maritim;Majapahit dan Gajah Mada;Mataram Kuno;Kerajaan Kutai;Kesultanan Aceh;Kesultanan Ternate dan Tidore;Kerajaan Gowa-Tallo;Kerajaan Sunda Pajajaran;Kerajaan Bali kuno;Samudra Pasai'],
['⚔️','Perjuangan & Pahlawan','Pangeran Diponegoro;Cut Nyak Dien;Pattimura;Sultan Hasanuddin;Pertempuran Surabaya;Kartini dan surat-suratnya;Proklamasi kemerdekaan;Ki Hajar Dewantara;Jenderal Sudirman;Bung Tomo'],
['🏺','Peradaban Kuno','Mesir Kuno;Mesopotamia;Romawi Kuno;Yunani Kuno;Lembah Indus;Maya dan Aztec;Peradaban Inca;Tiongkok Kuno;Persia Kuno;Peradaban Nusantara purba'],
['🌐','Sejarah Dunia & Peristiwa Besar','Revolusi Industri;Perang Dunia;Jalur Sutra;Renaisans;Penemuan benua baru;Perang Dingin;Penemuan mesin cetak;Runtuhnya Tembok Berlin;Pendaratan di bulan;Jatuhnya Konstantinopel'],
['😂','Sejarah Lucu & Unik','Pajak jenggot;Raja bermahkota aneh;Perang yang dimenangkan hewan;Hukum aneh zaman dulu;Penemuan tidak sengaja;Kebiasaan unik para bangsawan;Pesan rahasia konyol;Nama jabatan yang aneh;Kesalahan sejarah populer;Pesta paling mewah'],
['😱','Sejarah Menyeramkan','Wabah besar masa lalu;Kota yang terkubur;Benteng angker;Ritual kuno;Kutukan makam;Penjara tua;Kapal tanpa awak;Eksekusi di masa lampau;Kota hantu bersejarah;Katakombe bawah tanah'],
['🇮🇩','Budaya Indonesia','Batik dan filosofinya;Wayang kulit;Gamelan;Angklung;Tari Saman;Keris;Songket;Reog Ponorogo;Pencak silat;Noken Papua'],
['🎎','Tradisi, Upacara & Adat','Rambu Solo;Ngaben;Pasola;Lompat batu Nias;Sekaten;Tabuik;Kasada Bromo;Seren Taun;Tradisi pernikahan adat;Perayaan panen'],
['🍛','Kuliner Tradisional & Sejarahnya','Rendang;Gudeg;Papeda;Soto;Pempek;Tempe;Nasi tumpeng;Bubur Manado;Kopi tradisional;Jajanan pasar'],
['🏠','Rumah Adat & Pakaian Tradisional','Rumah Gadang;Tongkonan;Honai;Joglo;Rumah Panjang;Ulos;Kebaya;Baju bodo;Tenun ikat;Pakaian adat Bali'],
['💡','Penemuan & Tokoh Bersejarah','Penemuan listrik;Pesawat pertama;Penemuan penisilin;Mesin cetak Gutenberg;Telepon;Lampu pijar;Penemuan kertas;Kompas;Teleskop Galileo;Penemuan roda'],
['📜','Legenda & Cerita Rakyat','Malin Kundang;Sangkuriang;Roro Jonggrang;Timun Mas;Si Kancil;Danau Toba legenda;Bawang Merah Bawang Putih;Asal usul Banyuwangi;Legenda Candi Prambanan;Putri Mandalika']],
horor:[
['🏚️','Legenda Urban','Kuntilanak dan pohon kamboja;Wewe Gombel;Hantu jembatan tua;Sekolah angker;Telepon tengah malam;Hantu lift;Penunggu kamar mandi;Boneka yang bergerak;Rumah kosong di ujung gang;Suara langkah di lorong'],
['🌍','Tempat Angker Dunia','Menara London;Hutan Aokigahara dalam legenda;Pulau Poveglia;Kastil Bran;Katakombe Paris;Winchester House;Pulau Hashima;Hotel Stanley;Kota hantu Pripyat;Rumah Amityville'],
['🇮🇩','Tempat Angker Indonesia (Legenda)','Lawang Sewu;Gedung tua kota;Jembatan Ancol;Hutan Alas Purwo;Benteng Van den Bosch;Rumah sakit tua terbengkalai;Gunung Lawu;Rumah Si Pitung;Alas Roban;Pantai Selatan'],
['🔎','Misteri Dunia yang Belum Terpecahkan','Segitiga Bermuda;Naskah Voynich;Lingkaran Tanaman;Piramida dan pembangunannya;Situs Nazca;Menara Dyatlov Pass;Atlantis;Stonehenge;Patung Moai;Sinyal Wow!'],
['🐉','Makhluk Mitos & Cryptid','Bigfoot;Monster Loch Ness;Chupacabra;Yeti;Mothman;Orang Bunian;Genderuwo;Kraken;Naga;Jenglot dalam cerita'],
['🌊','Misteri Laut, Kapal & Pesawat Hilang','Mary Celeste;Flight 19;Segitiga Bermuda;Kapal hantu Octavius;Kapal Flying Dutchman;SS Waratah;Siren dan putri duyung;Laut Sargasso;Kapal bergerak sendiri;Suara aneh dari laut dalam'],
['🏠','Rumah Berhantu & Cerita Warga','Rumah kosong di ujung desa;Kamar nomor 13;Cermin tua;Sumur tua;Loteng yang berderit;Pintu yang terbuka sendiri;Boneka antik;Lonceng malam;Lorong gelap sekolah;Cerita pos ronda'],
['🌀','Fenomena Tak Terjelaskan','Lampu hantu;Suara dari kehampaan;Kabut aneh;Deja vu dan mimpi buruk;Kehilangan waktu;Paralisis tidur;Bayangan yang bergerak;Nyala api biru misterius;Hujan hewan;Suara siulan tengah malam'],
['⚰️','Misteri Sejarah Kelam','Kutukan Raja Tut;Koloni Roanoke yang hilang;Kota Pompeii;Hantu Menara London;Kematian misterius penjelajah;Makam kuno yang disegel;Benteng yang ditinggalkan;Kapal yang hilang;Desa kosong;Catatan harian yang terputus'],
['🕯️','Mitos & Pamali Nusantara','Pamali menyapu malam hari;Larangan bersiul malam;Jangan duduk di depan pintu;Pamali memotong kuku malam;Pantangan di hutan;Larangan saat senja;Sesaji dan penunggu;Pantangan di gunung;Pamali saat hamil;Larangan di laut'],
['🛸','UFO & Misteri Luar Angkasa','Roswell;Area 51;Sinyal radio dari luar angkasa;Bintang Tabby;Cahaya aneh di langit;Foto UFO terkenal;Misteri Mars;Lingkaran tanaman;Teori alien kuno;Benda tak dikenal di orbit'],
['📼','Kasus Misteri Terkenal & Rekaman Aneh','Rekaman suara EVP;Foto hantu terkenal;Video CCTV janggal;Diary tua;Radio yang menyala sendiri;Boneka Annabelle dalam legenda;Cermin terkutuk;Pesan di botol;Surat tanpa nama;Kaset rekaman misterius']]
};
/* 20 sudut cerita: setiap subjek mendapat 2 sudut berbeda → 10 subjek × 2 = 20 ide per layar 2 */
const FACT_ANGLES=[
 s=>['5 fakta yang jarang diketahui tentang '+s,`Lima fakta berurutan tentang ${s}, dari yang ringan hingga paling mengejutkan.`,`Fakta nomor lima tentang ${s} hampir tidak ada yang tahu.`,'Hook → fakta 1–5 → kesimpulan + CTA'],
 s=>['Mitos vs fakta: '+s,`Membedah mitos populer tentang ${s} dan meluruskannya dengan fakta.`,`Kebanyakan orang percaya hal ini tentang ${s}. Ternyata keliru.`,'Hook → mitos → fakta sebenarnya → pesan akhir'],
 s=>['Alasan di balik '+s,`Menjelaskan sebab dan proses yang membuat ${s} menjadi seperti sekarang.`,`Pernah bertanya-tanya kenapa ${s} bisa seperti ini?`,'Pertanyaan → sebab → proses → kesimpulan'],
 s=>['Awal mula '+s,`Menelusuri asal-usul ${s} dari kisah awalnya hingga bentuk yang kita kenal.`,`Semua berawal dari sesuatu yang tidak terduga.`,'Titik awal → perkembangan → kondisi sekarang'],
 s=>[s+' dalam 30 detik',`Rangkuman cepat dan padat tentang ${s} yang mudah diingat.`,`Cukup 30 detik untuk mengerti ${s}.`,'Hook → 3 poin inti → CTA'],
 s=>['Sisi tak terduga dari '+s,`Mengungkap sisi ${s} yang jarang terlihat dan mengubah cara pandang penonton.`,`Kamu mungkin hanya mengenal satu sisi dari ${s}.`,'Gambaran umum → sisi tersembunyi → refleksi'],
 s=>['Dulu vs sekarang: '+s,`Perbandingan visual bagaimana ${s} berubah dari masa ke masa.`,`Lihat betapa berbedanya ${s} dulu dan sekarang.`,'Kondisi dulu → titik perubahan → kondisi sekarang'],
 s=>['Rahasia di balik '+s,`Mengungkap detail tersembunyi yang membuat ${s} istimewa.`,`Ada rahasia kecil di balik ${s} yang jarang dibicarakan.`,'Teaser → petunjuk → pengungkapan'],
 s=>['Yang jarang diceritakan tentang '+s,`Sudut pandang berbeda tentang ${s} yang jarang muncul di pembahasan umum.`,`Ini bagian dari ${s} yang biasanya dilewatkan.`,'Hook → cerita tersembunyi → makna'],
 s=>['Bagaimana jika '+s+' tidak ada?',`Eksperimen berpikir: apa yang berubah bila ${s} tidak pernah ada.`,`Bayangkan dunia tanpa ${s}.`,'Pengandaian → dampak → kesimpulan'],
 s=>['Angka mengejutkan tentang '+s,`Menyajikan angka dan data paling mencolok tentang ${s} dengan visual sederhana.`,`Satu angka tentang ${s} ini akan membuatmu terdiam.`,'Angka → konteks → perbandingan → pesan'],
 s=>['Kesalahpahaman umum tentang '+s,`Meluruskan anggapan keliru yang sering muncul tentang ${s}.`,`Ternyata selama ini kita salah soal ${s}.`,'Anggapan umum → koreksi → bukti'],
 s=>[s+' dijelaskan dengan analogi sederhana',`Menjelaskan ${s} lewat perumpamaan sehari-hari agar mudah dipahami.`,`Bayangkan ${s} seperti hal yang kamu temui setiap hari.`,'Analogi → pemetaan → intisari'],
 s=>['3 hal wajib tahu tentang '+s,`Tiga poin penting tentang ${s} yang ringkas dan mudah dibagikan.`,`Hanya tiga hal tentang ${s} yang perlu kamu ingat.`,'Hook → poin 1–3 → ajakan menyimpan'],
 s=>['Perjalanan visual menelusuri '+s,`Tur sinematik melalui lokasi, detail dan suasana ${s}.`,`Ikuti perjalanan ini dan lihat ${s} dari dekat.`,'Pembuka → tur visual → momen puncak → penutup'],
 s=>['Kuis cepat: seberapa tahu kamu soal '+s+'?',`Format tebak-tebakan interaktif dengan jawaban dan penjelasan singkat tentang ${s}.`,`Coba jawab sebelum waktunya habis: seberapa tahu kamu soal ${s}?`,'Pertanyaan → jeda → jawaban → fakta tambahan'],
 s=>['Detail kecil dari '+s+' yang sering terlewat',`Menyoroti detail kecil pada ${s} yang membuatnya menarik.`,`Perhatikan detail kecil ini pada ${s}.`,'Gambaran besar → zoom detail → makna'],
 s=>['Top 5 hal paling menarik dari '+s,`Peringkat lima hal paling menarik terkait ${s}, dari nomor lima ke satu.`,`Nomor satu dari daftar ${s} ini paling mengejutkan.`,'Hook → hitung mundur 5–1 → ajakan komentar'],
 s=>['Dampak '+s+' bagi kehidupan kita',`Menghubungkan ${s} dengan kehidupan sehari-hari penonton.`,`Tanpa sadar, ${s} memengaruhi hidup kita.`,'Hook → hubungan ke keseharian → pesan'],
 s=>['Pelajaran tak terduga dari '+s,`Menarik pelajaran bermakna dari ${s} sebagai penutup yang membekas.`,`Dari ${s}, ada satu pelajaran yang patut diingat.`,'Cerita ringkas → pelajaran → CTA']
];
const HORROR_ANGLES=[
 s=>['Kisah di balik '+s,`Menceritakan legenda ${s} secara berurutan dengan suasana mencekam namun tidak vulgar.`,`Banyak yang bilang ceritanya benar. Tapi apa yang sebenarnya terjadi pada ${s}?`,'Pembuka suasana → legenda → kejanggalan → pertanyaan menggantung'],
 s=>['Kesaksian warga tentang '+s,`Narasi berdasarkan cerita warga tentang ${s}, disajikan sebagai kesaksian dan bukan fakta pasti.`,`Mereka mengaku melihat sesuatu terkait ${s}.`,'Pengantar → tiga kesaksian → kesimpulan terbuka'],
 s=>['Teori yang beredar tentang '+s,`Merangkum teori populer seputar ${s} dari yang supranatural hingga logis.`,`Ada tiga teori tentang ${s}, mana yang paling masuk akal?`,'Hook → teori 1–3 → tanya penonton'],
 s=>['Fakta vs legenda: '+s,`Memisahkan catatan yang terverifikasi dari cerita turun-temurun tentang ${s}.`,`Mana yang benar-benar terjadi, mana yang hanya cerita tentang ${s}?`,'Legenda → catatan nyata → perbandingan'],
 s=>['Kronologi misteri '+s,`Linimasa kejadian seputar ${s} dari awal hingga puncak misterinya.`,`Semuanya terasa biasa, sampai satu kejadian ini muncul pada ${s}.`,'Awal → eskalasi → puncak → misteri tersisa'],
 s=>['Jejak yang tertinggal dari '+s,`Menelusuri petunjuk dan benda peninggalan yang dikaitkan dengan ${s}.`,`Sisa jejak ini membuat ${s} sulit dilupakan.`,'Penemuan jejak → analisis → kemungkinan penjelasan'],
 s=>['Penjelasan ilmiah yang mungkin untuk '+s,`Membedah kemungkinan penjelasan rasional di balik cerita ${s}.`,`Bisakah sains menjelaskan ${s}?`,'Cerita → hipotesis ilmiah → sisa pertanyaan'],
 s=>['Mengapa orang percaya pada '+s,`Menelusuri budaya, rasa takut dan psikologi di balik kepercayaan pada ${s}.`,`Kenapa cerita ${s} terus hidup sampai sekarang?`,'Cerita → faktor budaya → psikologi → refleksi'],
 s=>['Satu malam bersama '+s,`Cerita pendek bernuansa horor ringan satu malam yang berpusat pada ${s}.`,`Malam itu terasa terlalu sunyi, lalu muncul ${s}.`,'Malam tenang → tanda aneh → puncak → penutup'],
 s=>['Peringatan dari orang tua tentang '+s,`Kisah pesan dan larangan turun-temurun yang berkaitan dengan ${s}.`,`Orang tua selalu bilang jangan lakukan ini, terutama soal ${s}.`,'Pesan → akibat dalam cerita → makna budaya'],
 s=>['Detail menyeramkan yang terlewat dari '+s,`Menyoroti detail kecil yang membuat cerita ${s} terasa janggal.`,`Detail kecil ini pada ${s} sering luput dari perhatian.`,'Gambaran umum → zoom detail → kejanggalan'],
 s=>['Versi lain cerita '+s,`Membandingkan beberapa versi cerita ${s} dari daerah atau era berbeda.`,`Ternyata ${s} punya versi lain yang lebih aneh.`,'Versi umum → versi lain → perbedaan → makna'],
 s=>['Tiga kejadian janggal terkait '+s,`Tiga peristiwa yang dikaitkan dengan ${s} dan sulit dijelaskan.`,`Kejadian ketiga tentang ${s} paling membuat bulu kuduk berdiri.`,'Hook → kejadian 1–3 → kesimpulan'],
 s=>['Apa yang ditemukan di '+s,`Cerita penemuan yang menambah misteri seputar ${s}.`,`Mereka tidak menyangka akan menemukan ini di ${s}.`,'Penjelajahan → penemuan → reaksi → teka-teki'],
 s=>['Pertanyaan tanpa jawaban tentang '+s,`Mengurai pertanyaan-pertanyaan yang sampai kini belum terjawab seputar ${s}.`,`Ada pertanyaan tentang ${s} yang tak seorang pun bisa jawab.`,'Pertanyaan 1–3 → petunjuk → ajakan berdiskusi'],
 s=>['Top 5 hal paling mencekam dari '+s,`Peringkat lima bagian paling mencekam dari cerita ${s}.`,`Nomor satu tentang ${s} membuat banyak orang enggan mendekat.`,'Hook → hitung mundur 5–1 → ajakan komentar'],
 s=>['Twist akhir dari '+s,`Cerita ${s} dengan akhir yang tak terduga dan membuat penasaran.`,`Semua tampak jelas, sampai kenyataan tentang ${s} terungkap.`,'Pembangunan suasana → petunjuk → twist'],
 s=>['Sebelum dan sesudah kejadian di '+s,`Membandingkan kondisi sebelum dan sesudah peristiwa yang dikaitkan dengan ${s}.`,`Semuanya berubah sejak peristiwa itu terjadi di ${s}.`,'Kondisi awal → peristiwa → akibat'],
 s=>['Mitos yang masih dipercaya tentang '+s,`Menelusuri mitos tentang ${s} yang bertahan hingga sekarang.`,`Sampai hari ini, orang masih percaya soal ${s}.`,'Mitos → asal → alasan bertahan'],
 s=>['Pelajaran dari cerita '+s,`Penutup reflektif yang mengambil makna dari cerita ${s} tanpa menakut-nakuti berlebihan.`,`Di balik ceritanya, ${s} menyimpan pesan.`,'Cerita → makna → ajakan komentar']
];
const stripEmoji=s=>String(s||'').replace(/^CUSTOM:/,'').replace(/^[^\p{L}\p{N}]+/u,'').trim();
function animCatByName(name){const n=stripEmoji(name);return ANIM_CATS.find(c=>c.name===n);}
function animSubOptions(catName){const c=animCatByName(catName);return c?ANIM_SUBS[c.key].map(x=>x[0]+' '+x[1]):null;}
/* Menghasilkan tepat 20 ide yang diturunkan dari kategori (layar 1) + kategori layar 2 yang dipilih */
function animIdeas(catName,subName){
 const c=animCatByName(catName)||ANIM_CATS[0];const angles=c.key==='horor'?HORROR_ANGLES:FACT_ANGLES;
 const clean=stripEmoji(subName);const found=(ANIM_SUBS[c.key]||[]).find(x=>x[1]===clean);
 const verify=c.key==='horor'?' · Catatan: sajikan sebagai legenda/cerita rakyat atau teori, bukan fakta pasti; hindari gore dan adegan kekerasan.':' · Catatan: verifikasi fakta dan angka dengan sumber tepercaya sebelum produksi.';
 let subjects=found?found[2].split(';'):null;
 const out=[];
 for(let i=0;i<20;i++){
  const subj=subjects?subjects[Math.floor(i/2)]:clean;
  const k=subjects?(i*2+ (i%2?1:0))%20:i; /* subjek sama → dua sudut berbeda */
  const a=angles[(subjects?((Math.floor(i/2))*2+(i%2)):i)%20](subj);
  out.push(`💡 ${String(i+1).padStart(2,'0')}. ${a[0]}||${a[1]} (${clean})||${a[2]}||${a[3]}${verify}`);
 }
 return out;
}
